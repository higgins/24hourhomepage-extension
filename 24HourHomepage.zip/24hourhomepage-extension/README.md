# 24hourhomepage-extension
An extension to set your browser homepage to 24HourHomepage.com
